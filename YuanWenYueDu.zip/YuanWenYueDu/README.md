#mini_read
