var app = getApp();
// var common = require("../../utils/common.js");
Page({
  data: {

  },

// 表单
  reg: function (e) {
    wx.showToast({
      title: '支付功能正在开发中...',
      duration: 2000
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      var that=this;

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

})